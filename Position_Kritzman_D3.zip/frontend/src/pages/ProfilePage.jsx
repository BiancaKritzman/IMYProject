import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import PostPreview from '../components/PostPreview';
import CreatePost from '../components/CreatePost';
import EditProfile from '../components/EditProfile';
import FriendList from '../components/FriendList';

function ProfilePage() {
  const { id } = useParams();
  const userIdAliases = {
    '1': '6abec6e7802c7674659df8a8',
    '2': '6abec788802c7674659df8ab'
  };
  const resolvedId = userIdAliases[String(id)] || String(id);

  const [currentUserId, setCurrentUserId] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [profileInfo, setProfileInfo] = useState({
    username: 'Loading...',
    quote: 'Loading bio...',
    age: 'Not specified',
    country: 'Loading...',
    hobbies: 'Loading...',
  });
  const [friendsList, setFriendsList] = useState([]);
  const [userPosts, setUserPosts] = useState([]);

  useEffect(() => {
    const loadData = async () => {
      try {
        const res = await fetch('/api/social-data');
        if (!res.ok) throw new Error('Failed to fetch profile data');

        const result = await res.json();
        const users = result.users || [];
        const posts = result.posts || [];
        const friendships = result.friendships || [];

        const matchedUser = users.find((user) => String(user._id || user.id) === String(resolvedId)) || users[0] || {};
        const userDisplayName = matchedUser.name || matchedUser.email?.split('@')[0] || `User ${String(resolvedId).slice(-4) || 'profile'}`;
        const userQuote = matchedUser.quote ?? matchedUser.bio ?? 'No quote available';
        const userAge = matchedUser.age ?? 'Not specified';
        const userCountry = matchedUser.country || 'Not specified';
        const userHobbies = Array.isArray(matchedUser.hobbies) ? matchedUser.hobbies : [];
        const allowedPostIds = Array.isArray(matchedUser.postIds)
          ? matchedUser.postIds.map((postId) => String(postId))
          : [];

        const matchedPosts = (allowedPostIds.length > 0
          ? posts.filter((post) => allowedPostIds.includes(String(post._id || post.id)))
          : posts.filter((post) => String(post.userId || post.user_id) === String(resolvedId)))
          .map((post) => ({
            id: String(post._id || post.id),
            title: post.title || '',
            imageUrl: post.imageUrl || '',
            username: matchedUser.name || matchedUser.email || '',
            description: post.caption || post.description || ''
          }));

        const matchedFriends = friendships
          .filter((friendship) => String(friendship.userId) === String(resolvedId))
          .map((friendship) => {
            const friend = users.find((user) => String(user._id || user.id) === String(friendship.friendId));
            return friend
              ? {
                  id: String(friend._id || friend.id),
                  name: friend.name || friend.email || 'Friend',
                  description: friend.bio || friend.quote || 'Photo enthusiast'
                }
              : null;
          })
          .filter(Boolean);

        setCurrentUserId(result.currentUserId || null);
        setProfileInfo({
          username: userDisplayName,
          quote: userQuote,
          age: userAge,
          country: userCountry,
          hobbies: userHobbies.length ? userHobbies.join(', ') : 'No hobbies listed'
        });
        setFriendsList(matchedFriends);
        setUserPosts(matchedPosts.length ? matchedPosts : []);
      } catch (error) {
        console.error('Failed to load profile data:', error);
        setProfileInfo({
          username: '',
          quote: '',
          age: '',
          country: '',
          hobbies: ''
        });
        setFriendsList([]);
        setUserPosts([]);
      }
    };

    loadData();
  }, [id]);

  const isOwnProfile = currentUserId ? String(currentUserId) === String(resolvedId) : false;

  const handleSaveProfile = (updatedData) => {
    setProfileInfo(updatedData);
    setIsEditing(false);
  };

  return (
    <main className="mx-auto max-w-[1100px] px-6 py-10">
      <div className="mb-6 flex items-center justify-between gap-4">
        <h2 className="[font-family:var(--font-heading)] text-3xl text-[#2b2118]">Info about {profileInfo.username}</h2>
        {isOwnProfile && (
          <button
            type="button"
            onClick={() => setIsEditing(!isEditing)}
            className="rounded-md bg-[#4a382a] px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-[#31241a]"
          >
            {isEditing ? 'Cancel Edit' : 'Edit Profile'}
          </button>
        )}
      </div>

      {isOwnProfile && isEditing ? (
        <EditProfile
          currentProfile={profileInfo}
          onSave={handleSaveProfile}
          onCancel={() => setIsEditing(false)}
        />
      ) : (
        <div className="mb-8 rounded-r-lg border-l-4 border-[#d9a05b] bg-[#fffdf9] p-5 text-[#2b2118] shadow-[0_4px_20px_rgba(43,33,24,0.05)]">
          <p className="mb-2 text-[#6e6052]"><strong className="text-[#2b2118]">Quote:</strong> "{profileInfo.quote}"</p>
          <p className="mb-2 text-[#6e6052]"><strong className="text-[#2b2118]">Age:</strong> {profileInfo.age}</p>
          <p className="mb-2 text-[#6e6052]"><strong className="text-[#2b2118]">Country:</strong> {profileInfo.country}</p>
          <p className="mb-0 text-[#6e6052]"><strong className="text-[#2b2118]">Hobbies:</strong> {profileInfo.hobbies}</p>
        </div>
      )}

      <FriendList friends={friendsList} />
      {isOwnProfile && <CreatePost />}

      <h3 className="[font-family:var(--font-heading)] mb-4 text-2xl text-[#2b2118]">What I've captured</h3>
      <div className="grid gap-7 md:grid-cols-2 xl:grid-cols-3">
        {userPosts.map((post) => (
          <PostPreview
            key={post.id}
            id={post.id}
            accountName={post.username}
            description={post.description}
          />
        ))}
      </div>
    </main>
  );
}

export default ProfilePage;