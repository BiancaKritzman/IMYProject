import React, { useState } from 'react';

function CreatePost() {
  const [title, setTitle] = useState('');
  const [imageUrl, setImageUrl] = useState('');

  const handlePost = (e) => {
    e.preventDefault();
    alert(`Post "${title}" created (stubbed)!`);
    setTitle('');
    setImageUrl('');
  };

  return (
    <form onSubmit={handlePost} className="mb-6 rounded-lg border border-[#e6ded3] bg-[#fffdf9] p-8 text-left shadow-[0_4px_20px_rgba(43,33,24,0.05)]">
      <h3 className="[font-family:var(--font-heading)] mb-4 text-2xl text-[#2b2118]">Create New Post</h3>
      <input
        type="text"
        placeholder="Post Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        required
        className="mb-4 w-full rounded-md border border-[#e6ded3] bg-[#f4efe6] px-4 py-3 text-[0.95rem] text-[#2b2118] outline-none transition focus:border-[#4a382a]"
      />
      <input
        type="url"
        placeholder="Image URL"
        value={imageUrl}
        onChange={(e) => setImageUrl(e.target.value)}
        required
        className="mb-4 w-full rounded-md border border-[#e6ded3] bg-[#f4efe6] px-4 py-3 text-[0.95rem] text-[#2b2118] outline-none transition focus:border-[#4a382a]"
      />
      <button type="submit" className="mt-2 w-full rounded-md bg-[#4a382a] px-4 py-3 text-sm font-medium text-white transition-colors hover:bg-[#31241a]">
        Publish
      </button>
    </form>
  );
}

export default CreatePost;