import React from 'react';
import ProfilePreview from './ProfilePreview';

export default function FriendList({ friends }) {
  return (
    <section className="mb-12">
      <h3 className="[font-family:var(--font-heading)] mb-4 text-2xl text-[#2b2118]">Friends</h3>
      <div className="grid gap-7 md:grid-cols-2 xl:grid-cols-3">
        {friends.map((friend) => (
          <ProfilePreview
            key={friend.id}
            id={friend.id}
            accountName={friend.name}
            description={friend.description}
          />
        ))}
      </div>
    </section>
  );
}